<?php

namespace App\Services;

use App\Repositories\LeadRepository;
use App\Models\Lead;
use Illuminate\Support\Facades\Auth;
use JWTAuth;
// use Hash;

class LeadService extends LeadRepository
{
    
}