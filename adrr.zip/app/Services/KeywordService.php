<?php

namespace App\Services;

use App\Repositories\KeywordRepository;
use App\Models\Keyword;
use Illuminate\Support\Facades\Auth;
use JWTAuth;
// use Hash;

class KeywordService extends KeywordRepository
{
	
}