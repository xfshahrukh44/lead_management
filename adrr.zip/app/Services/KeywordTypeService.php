<?php

namespace App\Services;

use App\Repositories\KeywordTypeRepository;
use App\Models\Keyword_Type;
use Illuminate\Support\Facades\Auth;
use JWTAuth;
// use Hash;

class KeywordTypeService extends KeywordTypeRepository
{
	
}