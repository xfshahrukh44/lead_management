<?php

namespace App\Exceptions\Logo;

use Exception;

class AllLogoException extends Exception
{
    //
}
