<?php

namespace App\Exceptions\Logo;

use Exception;

class CreateLogoException extends Exception
{
    //
}
