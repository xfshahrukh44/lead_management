<?php

namespace App\Exceptions\Logo;

use Exception;

class DeleteLogoException extends Exception
{
    //
}
