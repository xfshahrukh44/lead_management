<?php

namespace App\Exceptions\Logo;

use Exception;

class UpdateLogoException extends Exception
{
    //
}
