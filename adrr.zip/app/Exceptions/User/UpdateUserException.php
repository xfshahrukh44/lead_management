<?php

namespace App\Exceptions\User;

use Exception;

class UpdateUserException extends Exception
{
    //
}
