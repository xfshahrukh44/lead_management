<?php

namespace App\Exceptions\User;

use Exception;

class CreateUserException extends Exception
{
    //
}
