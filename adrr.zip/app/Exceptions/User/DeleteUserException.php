<?php

namespace App\Exceptions\User;

use Exception;

class DeleteUserException extends Exception
{
    //
}
