<?php

namespace App\Exceptions\Video;

use Exception;

class AllVideoException extends Exception
{
    //
}
