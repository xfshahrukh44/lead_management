<?php

namespace App\Exceptions\Video;

use Exception;

class DeleteVideoException extends Exception
{
    //
}
