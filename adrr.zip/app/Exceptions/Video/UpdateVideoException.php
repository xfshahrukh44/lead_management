<?php

namespace App\Exceptions\Video;

use Exception;

class UpdateVideoException extends Exception
{
    //
}
