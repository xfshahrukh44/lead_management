<?php

namespace App\Exceptions\Video;

use Exception;

class CreateVideoException extends Exception
{
    //
}
