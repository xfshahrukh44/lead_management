<?php

namespace App\Exceptions\Keyword;

use Exception;

class DeleteKeywordException extends Exception
{
    //
}
