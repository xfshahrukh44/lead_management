<?php

namespace App\Exceptions\Keyword;

use Exception;

class UpdateKeywordException extends Exception
{
    //
}
