<?php

namespace App\Exceptions\Keyword;

use Exception;

class AllKeywordException extends Exception
{
    //
}
