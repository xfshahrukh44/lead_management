<?php

namespace App\Exceptions\Keyword;

use Exception;

class CreateKeywordException extends Exception
{
    //
}
