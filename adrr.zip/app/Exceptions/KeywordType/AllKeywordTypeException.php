<?php

namespace App\Exceptions\KeywordType;

use Exception;

class AllKeywordTypeException extends Exception
{
    //
}
