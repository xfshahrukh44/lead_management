<?php

namespace App\Exceptions\KeywordType;

use Exception;

class UpdateKeywordTypeException extends Exception
{
    //
}
