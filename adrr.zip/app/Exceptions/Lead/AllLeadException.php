<?php

namespace App\Exceptions\Lead;

use Exception;

class AllLeadException extends Exception
{
    //
}
