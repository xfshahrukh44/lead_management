<?php

namespace App\Exceptions\Lead;

use Exception;

class UpdateLeadException extends Exception
{
    //
}
