<?php

namespace App\Exceptions\Lead;

use Exception;

class DeleteLeadException extends Exception
{
    //
}
