@csrf
<div class="modal-body row">
	<!-- website_keyword_1 -->
	<div class="form-group col-md-12">
		<label for="">Keyword Type</label>
		<input type="text" name="keyword_name" placeholder="Enter KeyWord Type" class="form-control keyword_type">
	</div>
</div>